from pathlib import Path
from fastapi import FastAPI, Request
from fastapi.staticfiles import StaticFiles
from fastapi.templating import Jinja2Templates
from dotenv import load_dotenv

from app.config import settings
from app.database import init_db
from app.routes.auth import router as auth_router
from app.routes.planners import router as planner_router
from app.routes.pages import router as pages_router

load_dotenv()

BASE_DIR = Path(__file__).resolve().parent.parent
Path(settings.UPLOAD_DIR).mkdir(parents=True, exist_ok=True)

app = FastAPI(title=settings.APP_NAME, version="1.0.0")
app.mount("/static", StaticFiles(directory=str(BASE_DIR / "app" / "static")), name="static")
app.mount("/uploads", StaticFiles(directory=settings.UPLOAD_DIR), name="uploads")
templates = Jinja2Templates(directory=str(BASE_DIR / "app" / "templates"))
app.state.templates = templates

@app.on_event("startup")
def startup():
    init_db()

@app.get("/health")
def health():
    return {"status": "ok", "service": settings.APP_NAME}

app.include_router(pages_router)
app.include_router(auth_router)
app.include_router(planner_router, prefix="/api")
