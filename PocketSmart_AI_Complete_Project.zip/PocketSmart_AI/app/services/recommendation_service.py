import json
from sqlalchemy.orm import Session
from app.models import Recommendation
from app.services.gemini_utils import generate_home, generate_party, generate_jewelry

def generate_and_save(db: Session, user_id: int, planner: str, data: dict):
    generators = {"home": generate_home, "party": generate_party, "jewelry": generate_jewelry}
    result = generators[planner](data)
    row = Recommendation(user_id=user_id, planner_type=planner,
                         input_json=json.dumps(data), result_json=json.dumps(result))
    db.add(row)
    db.commit()
    db.refresh(row)
    return result, row
