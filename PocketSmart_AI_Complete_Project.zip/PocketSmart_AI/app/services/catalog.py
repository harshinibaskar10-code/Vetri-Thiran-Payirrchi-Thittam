CATALOG = {
    "home": [
        {"name": "Minimal LED Ceiling Light", "platform": "Amazon", "price": 1299, "category": "lighting"},
        {"name": "Modern 3-Seater Sofa", "platform": "IKEA", "price": 18999, "category": "furniture"},
        {"name": "Compact Study Table", "platform": "Amazon", "price": 5499, "category": "furniture"},
        {"name": "Decorative Wall Art Set", "platform": "Flipkart", "price": 899, "category": "decor"},
        {"name": "Ceiling Fan", "platform": "Amazon", "price": 2499, "category": "lighting"},
    ],
    "party": [
        {"name": "Birthday Catering Package", "platform": "Swiggy", "price": 4999, "category": "food"},
        {"name": "Party Food Combo", "platform": "Zomato", "price": 2999, "category": "food"},
        {"name": "Budget Event Stay", "platform": "OYO", "price": 3499, "category": "venue"},
        {"name": "Basic Decoration Package", "platform": "Local Vendor", "price": 3999, "category": "decoration"},
    ],
    "jewelry": [
        {"name": "Gold-Plated Necklace Set", "platform": "Amazon", "price": 1599, "category": "necklace"},
        {"name": "Traditional Jhumka Earrings", "platform": "Flipkart", "price": 699, "category": "earrings"},
        {"name": "Minimal Bracelet", "platform": "Amazon", "price": 499, "category": "bracelet"},
        {"name": "Temple-Style Jewelry Set", "platform": "Flipkart", "price": 2299, "category": "set"},
    ],
}

def get_budget_items(planner: str, budget: float):
    items = [x for x in CATALOG[planner] if x["price"] <= budget]
    return sorted(items, key=lambda x: x["price"])
