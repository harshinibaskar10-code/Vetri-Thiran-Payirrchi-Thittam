import json
from typing import Any
from app.config import settings
from app.services.catalog import get_budget_items

try:
    import google.generativeai as genai
except ImportError:
    genai = None

def _mock(planner: str, data: dict[str, Any]) -> dict:
    budget = float(data["budget"])
    items = get_budget_items(planner, budget)
    return {
        "planner": planner,
        "budget": budget,
        "summary": f"Curated {planner} recommendations within a budget of ₹{budget:,.0f}.",
        "allocation": _allocation(planner, budget),
        "recommendations": items[:6],
        "source": "Local mock catalog + rule-based fallback",
    }

def _allocation(planner: str, budget: float) -> dict:
    if planner == "home":
        return {"Furniture": round(budget*.45,2), "Lighting": round(budget*.20,2), "Decor": round(budget*.20,2), "Buffer": round(budget*.15,2)}
    if planner == "party":
        return {"Food": round(budget*.45,2), "Decoration": round(budget*.20,2), "Venue": round(budget*.25,2), "Buffer": round(budget*.10,2)}
    return {"Necklace/Set": round(budget*.45,2), "Earrings": round(budget*.25,2), "Bracelet": round(budget*.15,2), "Buffer": round(budget*.15,2)}

def _gemini(prompt: str) -> dict | None:
    if settings.USE_MOCK_RECOMMENDATIONS or not settings.GEMINI_API_KEY or genai is None:
        return None
    try:
        genai.configure(api_key=settings.GEMINI_API_KEY)
        model = genai.GenerativeModel(settings.GEMINI_MODEL)
        response = model.generate_content(prompt)
        text = response.text.strip()
        if text.startswith("```"):
            text = text.strip("`")
            if text.startswith("json"):
                text = text[4:]
        return json.loads(text)
    except Exception:
        return None

def generate_home(data: dict) -> dict:
    fallback = _mock("home", data)
    prompt = f"""You are PocketSmart AI. Create budget-aware home interior recommendations.
Return JSON with keys summary, allocation, recommendations.
Budget: ₹{data['budget']}; room: {data.get('room_type')}; style: {data.get('style')}; items: {data.get('items', [])}.
Use practical Indian-market suggestions. Do not invent live prices; use the supplied catalog where possible.
Catalog: {json.dumps(fallback['recommendations'])}"""
    result = _gemini(prompt)
    return result or fallback

def generate_party(data: dict) -> dict:
    fallback = _mock("party", data)
    prompt = f"""You are PocketSmart AI. Plan a party within budget.
Return JSON with keys summary, allocation, recommendations.
Budget: ₹{data['budget']}; guests: {data['guests']}; event: {data['event_type']}; venue: {data['venue']}.
Catalog: {json.dumps(fallback['recommendations'])}"""
    result = _gemini(prompt)
    return result or fallback

def generate_jewelry(data: dict) -> dict:
    fallback = _mock("jewelry", data)
    prompt = f"""You are PocketSmart AI. Recommend jewelry matching an occasion and outfit.
Return JSON with keys summary, allocation, recommendations.
Budget: ₹{data['budget']}; occasion: {data['occasion']}; style: {data['style']}; outfit color: {data.get('outfit_color')}.
Catalog: {json.dumps(fallback['recommendations'])}"""
    result = _gemini(prompt)
    return result or fallback
