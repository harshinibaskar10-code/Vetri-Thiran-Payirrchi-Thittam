function money(v){return "₹"+Number(v||0).toLocaleString("en-IN")}
function renderResult(data){
 const result=document.getElementById("result"); if(!result)return;
 let html=`<div class="result-box"><h2>AI Recommendations</h2><p class="muted">${data.summary||"Your personalized plan is ready."}</p>`;
 if(data.allocation){html+=`<div class="allocation">`; for(const [k,v] of Object.entries(data.allocation)){html+=`<div class="alloc"><small>${k}</small><b>${money(v)}</b></div>`} html+=`</div>`}
 if(data.recommendations?.length){for(const x of data.recommendations){html+=`<div class="recommendation"><div><b>${x.name||"Recommendation"}</b><div class="muted">${x.platform||""} · ${x.category||""}</div></div><strong>${money(x.price)}</strong></div>`}}
 html+=`<p class="muted">Source: ${data.source||"Gemini AI"}</p></div>`; result.innerHTML=html;
}
document.addEventListener("submit",async e=>{
 const form=e.target;if(!form.matches(".planner-form"))return;e.preventDefault();
 const button=form.querySelector("button");button.disabled=true;button.textContent="Generating…";
 try{const res=await fetch(form.dataset.endpoint,{method:"POST",body:new FormData(form)});const data=await res.json();if(!res.ok)throw new Error(data.error||data.detail||"Request failed");renderResult(data)}
 catch(err){document.getElementById("result").innerHTML=`<div class="result-box"><b>Something went wrong.</b><p class="muted">${err.message}</p></div>`}
 finally{button.disabled=false;button.textContent="Generate Recommendations ✦"}
})
