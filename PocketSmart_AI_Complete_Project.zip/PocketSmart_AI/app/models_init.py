# Compatibility marker; SQLAlchemy models are defined in app/models.py.
