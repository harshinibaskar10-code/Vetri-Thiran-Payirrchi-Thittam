from typing import Optional
from pydantic import BaseModel, Field

class RegisterRequest(BaseModel):
    name: str = Field(min_length=2, max_length=120)
    email: str
    password: str = Field(min_length=6, max_length=128)

class LoginRequest(BaseModel):
    email: str
    password: str

class HomeRequest(BaseModel):
    budget: float = Field(gt=0)
    room_type: str = "Living Room"
    style: str = "Modern"
    items: list[str] = []

class PartyRequest(BaseModel):
    budget: float = Field(gt=0)
    guests: int = Field(gt=0, le=10000)
    event_type: str = "Birthday"
    venue: str = "Any"

class JewelryRequest(BaseModel):
    budget: float = Field(gt=0)
    occasion: str = "Wedding"
    style: str = "Traditional"
    outfit_color: Optional[str] = None
    image_path: Optional[str] = None
