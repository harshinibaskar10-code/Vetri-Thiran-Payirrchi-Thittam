import os
from pydantic_settings import BaseSettings, SettingsConfigDict

class Settings(BaseSettings):
    APP_NAME: str = "PocketSmart AI"
    SECRET_KEY: str = "change-this-secret-key-in-production"
    DATABASE_URL: str = "sqlite:///./pocketsmart.db"
    GEMINI_API_KEY: str = ""
    GEMINI_MODEL: str = "gemini-1.5-flash"
    USE_MOCK_RECOMMENDATIONS: bool = True
    ACCESS_TOKEN_EXPIRE_MINUTES: int = 60
    UPLOAD_DIR: str = "uploads"

    model_config = SettingsConfigDict(env_file=".env", extra="ignore")

settings = Settings()
