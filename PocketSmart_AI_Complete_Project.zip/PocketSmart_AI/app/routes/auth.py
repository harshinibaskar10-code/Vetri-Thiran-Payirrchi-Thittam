from fastapi import APIRouter, Depends, Form, Request
from fastapi.responses import RedirectResponse, JSONResponse
from sqlalchemy.orm import Session
from app.database import get_db
from app.models import User
from app.security import hash_password, verify_password, create_access_token

router = APIRouter()

@router.post("/register")
def register(name: str = Form(...), email: str = Form(...), password: str = Form(...), db: Session = Depends(get_db)):
    email = email.strip().lower()
    if db.query(User).filter(User.email == email).first():
        return JSONResponse({"error": "Email already registered"}, status_code=400)
    user = User(name=name.strip(), email=email, password_hash=hash_password(password))
    db.add(user); db.commit(); db.refresh(user)
    response = RedirectResponse("/dashboard", status_code=303)
    response.set_cookie("access_token", create_access_token(user.id), httponly=True, samesite="lax")
    return response

@router.post("/login")
def login(email: str = Form(...), password: str = Form(...), db: Session = Depends(get_db)):
    user = db.query(User).filter(User.email == email.strip().lower()).first()
    if not user or not verify_password(password, user.password_hash):
        return JSONResponse({"error": "Invalid email or password"}, status_code=401)
    response = RedirectResponse("/dashboard", status_code=303)
    response.set_cookie("access_token", create_access_token(user.id), httponly=True, samesite="lax")
    return response

@router.get("/logout")
def logout():
    response = RedirectResponse("/", status_code=303)
    response.delete_cookie("access_token")
    return response
