import json, os, uuid
from fastapi import APIRouter, Depends, File, Form, UploadFile
from fastapi.responses import JSONResponse
from sqlalchemy.orm import Session
from app.database import get_db
from app.dependencies import get_current_user
from app.services.recommendation_service import generate_and_save
from app.config import settings

router = APIRouter()

@router.post("/generate-home")
def generate_home(budget: float = Form(...), room_type: str = Form("Living Room"),
                  style: str = Form("Modern"), items: str = Form(""),
                  user=Depends(get_current_user), db: Session=Depends(get_db)):
    data = {"budget": budget, "room_type": room_type, "style": style,
            "items": [x.strip() for x in items.split(",") if x.strip()]}
    result, _ = generate_and_save(db, user.id, "home", data)
    return JSONResponse(result)

@router.post("/generate-party")
def generate_party(budget: float = Form(...), guests: int = Form(...),
                   event_type: str = Form("Birthday"), venue: str = Form("Any"),
                   user=Depends(get_current_user), db: Session=Depends(get_db)):
    data = {"budget": budget, "guests": guests, "event_type": event_type, "venue": venue}
    result, _ = generate_and_save(db, user.id, "party", data)
    return JSONResponse(result)

@router.post("/generate-jewelry")
async def generate_jewelry(budget: float = Form(...), occasion: str = Form("Wedding"),
                           style: str = Form("Traditional"), outfit_color: str = Form(""),
                           outfit_image: UploadFile | None = File(None),
                           user=Depends(get_current_user), db: Session=Depends(get_db)):
    image_path = None
    if outfit_image and outfit_image.filename:
        ext = os.path.splitext(outfit_image.filename)[1].lower()
        if ext not in {".jpg", ".jpeg", ".png", ".webp"}:
            return JSONResponse({"error": "Only JPG, JPEG, PNG and WEBP images are allowed"}, status_code=400)
        filename = f"{uuid.uuid4().hex}{ext}"
        destination = os.path.join(settings.UPLOAD_DIR, filename)
        with open(destination, "wb") as f:
            f.write(await outfit_image.read())
        image_path = destination
    data = {"budget": budget, "occasion": occasion, "style": style,
            "outfit_color": outfit_color, "image_path": image_path}
    result, _ = generate_and_save(db, user.id, "jewelry", data)
    return JSONResponse(result)

@router.get("/recommendations-details/{recommendation_id}")
def recommendation_details(recommendation_id: int, user=Depends(get_current_user), db: Session=Depends(get_db)):
    from app.models import Recommendation
    row = db.query(Recommendation).filter(Recommendation.id == recommendation_id,
                                            Recommendation.user_id == user.id).first()
    if not row:
        return JSONResponse({"error": "Recommendation not found"}, status_code=404)
    return JSONResponse({"id": row.id, "planner": row.planner_type,
                         "input": json.loads(row.input_json), "result": json.loads(row.result_json)})
