import json
from fastapi import APIRouter, Depends, Request
from fastapi.responses import RedirectResponse
from sqlalchemy.orm import Session
from app.database import get_db
from app.dependencies import get_current_user
from app.models import Recommendation

router = APIRouter()

def templates(request: Request):
    return request.app.state.templates if hasattr(request.app.state, "templates") else None

@router.get("/")
def home(request: Request):
    return request.app.state.templates.TemplateResponse("index.html", {"request": request})

@router.get("/register")
def register_page(request: Request):
    return request.app.state.templates.TemplateResponse("register.html", {"request": request})

@router.get("/login")
def login_page(request: Request):
    return request.app.state.templates.TemplateResponse("login.html", {"request": request})

@router.get("/dashboard")
def dashboard(request: Request, user=Depends(get_current_user), db: Session=Depends(get_db)):
    rows = db.query(Recommendation).filter(Recommendation.user_id == user.id).order_by(Recommendation.created_at.desc()).limit(5).all()
    return request.app.state.templates.TemplateResponse("dashboard.html", {"request": request, "user": user, "rows": rows})

@router.get("/planner/home")
def home_planner(request: Request, user=Depends(get_current_user)):
    return request.app.state.templates.TemplateResponse("home_planner.html", {"request": request, "user": user})

@router.get("/planner/party")
def party_planner(request: Request, user=Depends(get_current_user)):
    return request.app.state.templates.TemplateResponse("party_planner.html", {"request": request, "user": user})

@router.get("/planner/jewelry")
def jewelry_planner(request: Request, user=Depends(get_current_user)):
    return request.app.state.templates.TemplateResponse("jewelry_planner.html", {"request": request, "user": user})

@router.get("/history")
def history(request: Request, user=Depends(get_current_user), db: Session=Depends(get_db)):
    rows = db.query(Recommendation).filter(Recommendation.user_id == user.id).order_by(Recommendation.created_at.desc()).all()
    return request.app.state.templates.TemplateResponse("history.html", {"request": request, "user": user, "rows": rows})
