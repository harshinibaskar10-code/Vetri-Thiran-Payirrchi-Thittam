# PocketSmart AI – Your Smart Budget & Recommendation Assistant

PocketSmart AI is a FastAPI + Jinja2 web application based on the supplied project documentation. It provides:
- Home Interior Budget Planner
- Party Budget Planner
- Jewelry Budget Planner with optional outfit image upload
- Gemini AI recommendation service
- Mock/fallback recommendations so the application can run without an API key
- Registration, login, JWT authentication
- Dashboard and recommendation history
- SQLite database
- Responsive HTML/CSS/JavaScript UI

## 1. VS Code setup

Requirements:
- Python 3.10+
- VS Code
- Internet connection only when installing packages or using Gemini

Open this folder in VS Code.

### Windows
```powershell
python -m venv .venv
.venv\Scripts\activate
pip install -r requirements.txt
copy .env.example .env
```

### macOS/Linux
```bash
python3 -m venv .venv
source .venv/bin/activate
pip install -r requirements.txt
cp .env.example .env
```

Run:
```bash
uvicorn app.main:app --reload
```

Open:
http://127.0.0.1:8000

## 2. Gemini configuration

The app works in mock mode by default.

Edit `.env`:
```env
GEMINI_API_KEY=your_key_here
GEMINI_MODEL=gemini-1.5-flash
USE_MOCK_RECOMMENDATIONS=false
```

The supplied documentation refers to Gemini 1.5 Flash Pro. The model name is configurable because model availability can change. Use a model name available to your Google AI account.

## 3. Main routes

- `/` – landing page
- `/register` – registration
- `/login` – login
- `/dashboard` – user dashboard
- `/planner/home` – home planner
- `/planner/party` – party planner
- `/planner/jewelry` – jewelry planner
- `/history` – recommendation history
- `/api/generate-home`
- `/api/generate-party`
- `/api/generate-jewelry`
- `/health`

## 4. Testing

```bash
pytest -q
```

The tests cover health checks, registration/login flow, protected dashboard access, and planner API behavior.

## 5. Project note

Third-party marketplace/vendor integrations described in the documentation are represented by a local mock catalog. This makes the project runnable without private marketplace credentials or scraping. The recommendation service can combine the mock catalog with Gemini-generated reasoning.
